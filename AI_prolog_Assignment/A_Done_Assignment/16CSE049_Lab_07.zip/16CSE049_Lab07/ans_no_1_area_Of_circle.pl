go:- write("Enter the radius of Circle :"),nl, read(R),nl, area(R).
area(R):- AREA is(3.1416*R*R),write(AREA).


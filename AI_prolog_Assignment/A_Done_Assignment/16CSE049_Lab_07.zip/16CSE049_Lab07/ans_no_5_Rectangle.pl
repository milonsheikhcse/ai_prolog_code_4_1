points(a,1,-2).
points(b,-3,0).
points(c,5,6).
points(d,1,8).


dist(N1,N2,A_B):- points(N1,X1,Y1), points(N2,X2,Y2),
A_B is sqrt((X2-X1)**2+(Y2-Y1)**2).

dist(N1,N2,B_C):-
points(N1,X1,Y1),
points(N2,X2,Y2),
B_C is sqrt((X2-X1)**2+(Y2-Y1)**2).

dist(N1,N2,C_D):-
points(N1,X1,Y1),
points(N2,X2,Y2),
C_D is sqrt((X2-X1)**2 + (Y2-Y1)**2).

dist(N1,N2,D_A):-
points(N1,X1,Y1),
points(N2,X2,Y2),
D_A is sqrt((X2-X1)**2 + (Y2-Y1)**2).

rectangle(A,B,C,D,T):- dist(a,b,A_B),dist(c,d,C_D);  dist(b,d,B_D),dist(a,c,A_C).


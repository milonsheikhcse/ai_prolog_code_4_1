%distantce of two point %
% 1st point is X1,Y1%
% 2nd point is X2,Y2%

dist((X1,Y1),(X2,Y2),Ans):- Ans is sqrt((X2-X1)**2+(Y2-Y1)**2).

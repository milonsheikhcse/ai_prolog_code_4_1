go:- write("Enter the base of Triangle :"),nl, read(Base),nl,write("Enter height of Trinagle: "),nl,read(Height),area(Base,Height).

area(Base,Height):- Area is(0.5*Base*Height),write(Area).


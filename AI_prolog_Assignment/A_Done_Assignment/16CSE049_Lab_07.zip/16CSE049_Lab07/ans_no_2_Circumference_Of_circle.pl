

go:-write("Enter the radius of circle :"),nl,read(R),circunference(R).


circumference(R):- Result is(2*3.1416*R).write(Result).

